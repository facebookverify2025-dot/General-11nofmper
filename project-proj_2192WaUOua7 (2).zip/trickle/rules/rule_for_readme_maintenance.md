When updating the project

- Always check if README.md in trickle/notes needs to be updated
- Update README.md when adding new features, changing contact info, or modifying key functionality
- Keep README.md concise and informative
- Include all important contact details and credentials