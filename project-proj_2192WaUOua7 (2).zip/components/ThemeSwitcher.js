function ThemeSwitcher({ currentTheme, onThemeChange }) {
  try {
    const [isOpen, setIsOpen] = React.useState(false);
    
    const themes = [
      { id: 'default', name: 'برتقالي', color: '#ff6b35' },
      { id: 'blue', name: 'أزرق', color: '#2563eb' },
      { id: 'green', name: 'أخضر', color: '#059669' },
      { id: 'purple', name: 'بنفسجي', color: '#7c3aed' }
    ];

    return (
      <div className="fixed bottom-20 left-4 sm:bottom-4 sm:left-4 md:bottom-6 md:left-6 z-40" data-name="theme-switcher" data-file="components/ThemeSwitcher.js">
        <div className="relative">
          {isOpen && (
            <div className="absolute bottom-14 md:bottom-16 left-0 bg-white rounded-lg shadow-xl p-2 md:p-3 space-y-2 min-w-[130px] md:min-w-[140px]">
              {themes.map(theme => (
                <button
                  key={theme.id}
                  onClick={async () => {
                    onThemeChange(theme.id);
                    
                    try {
                      const settings = await Database.getSettings();
                      if (settings.objectData?.clickSound) {
                        const audio = new Audio(settings.objectData.clickSound);
                        audio.play().catch(() => {});
                      }
                    } catch (error) {}
                    
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-gray-100 transition-all ${
                    currentTheme === theme.id ? 'bg-gray-100' : ''
                  }`}
                >
                  <div 
                    className="w-6 h-6 rounded-full border-2 border-gray-300"
                    style={{ backgroundColor: theme.color }}
                  ></div>
                  <span className="font-semibold text-sm">{theme.name}</span>
                </button>
              ))}
            </div>
          )}
          
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="w-12 h-12 md:w-14 md:h-14 bg-white rounded-full shadow-lg flex items-center justify-center hover:shadow-xl transition-all"
          >
            <div className="icon-palette text-xl md:text-2xl text-gray-700"></div>
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ThemeSwitcher error:', error);
    return null;
  }
}