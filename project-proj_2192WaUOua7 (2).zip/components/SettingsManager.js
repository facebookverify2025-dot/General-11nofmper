function SettingsManager({ onUpdate }) {
  try {
    const [settings, setSettings] = React.useState(null);
    const [data, setData] = React.useState({});

    React.useEffect(() => {
      loadSettings();
    }, []);

    const loadSettings = async () => {
      const s = await Database.getSettings();
      setSettings(s);
      setData(s.objectData || {});
    };

    const handleSave = async () => {
      if (!settings || !settings.objectId) {
        alert('خطأ في تحميل الإعدادات. الرجاء إعادة تحميل الصفحة');
        return;
      }
      
      try {
        const updatedData = {
          companyEmail: data.companyEmail || 'info@general.com',
          whatsappNumber: data.whatsappNumber || '+201034551612',
          facebookUrl: data.facebookUrl || '',
          instagramUrl: data.instagramUrl || '',
          heroImageUrl: data.heroImageUrl || ''
        };
        
        await Database.updateSettings(settings.objectId, updatedData);
        alert('تم حفظ الإعدادات');
        onUpdate();
      } catch (error) {
        console.error('Settings save error:', error);
        alert('حدث خطأ في حفظ الإعدادات: ' + error.message);
      }
    };

    if (!settings) return <div>جاري التحميل...</div>;

    return (
      <div className="space-y-4">
        <div>
          <label className="block font-semibold mb-2">إيميل الشركة</label>
          <input type="email" value={data.companyEmail || ''} 
            onChange={e => setData({...data, companyEmail: e.target.value})}
            className="w-full px-4 py-2 border rounded-lg" />
        </div>
        
        <div>
          <label className="block font-semibold mb-2">رقم واتساب</label>
          <input type="text" value={data.whatsappNumber || ''} 
            onChange={e => setData({...data, whatsappNumber: e.target.value})}
            className="w-full px-4 py-2 border rounded-lg" />
        </div>
        
        <div>
          <label className="block font-semibold mb-2">رابط فيسبوك</label>
          <input type="url" value={data.facebookUrl || ''} 
            onChange={e => setData({...data, facebookUrl: e.target.value})}
            className="w-full px-4 py-2 border rounded-lg" />
        </div>
        
        <div>
          <label className="block font-semibold mb-2">رابط إنستجرام</label>
          <input type="url" value={data.instagramUrl || ''} 
            onChange={e => setData({...data, instagramUrl: e.target.value})}
            className="w-full px-4 py-2 border rounded-lg" />
        </div>
        
        <button onClick={handleSave} className="btn-primary">حفظ الإعدادات</button>
      </div>
    );
  } catch (error) {
    console.error('SettingsManager error:', error);
    return null;
  }
}