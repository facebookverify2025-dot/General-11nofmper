function HeroBackgrounds({ onSelect }) {
  try {
    const backgrounds = [
      {
        id: 1,
        url: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا فاخرة'
      },
      {
        id: 2,
        url: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا حديثة'
      },
      {
        id: 3,
        url: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا عصرية'
      },
      {
        id: 4,
        url: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا راقية'
      },
      {
        id: 5,
        url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا مميزة'
      },
      {
        id: 6,
        url: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا أنيقة'
      },
      {
        id: 7,
        url: 'https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا فخمة'
      },
      {
        id: 8,
        url: 'https://images.unsplash.com/photo-1600573472591-ee6b68d14c68?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا جذابة'
      },
      {
        id: 9,
        url: 'https://images.unsplash.com/photo-1600210492493-0946911123ea?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا متميزة'
      },
      {
        id: 10,
        url: 'https://images.unsplash.com/photo-1600607687644-c7171b42498b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80',
        name: 'فيلا رائعة'
      }
    ];

    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4" data-name="hero-backgrounds" data-file="components/HeroBackgrounds.js">
        {backgrounds.map(bg => (
          <div 
            key={bg.id}
            onClick={() => onSelect(bg.url)}
            className="relative cursor-pointer rounded-lg overflow-hidden hover:ring-4 ring-[var(--primary-color)] transition-all group"
          >
            <img 
              src={bg.url} 
              alt={bg.name}
              className="w-full h-32 object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all flex items-center justify-center">
              <span className="text-white font-bold opacity-0 group-hover:opacity-100 transition-all">
                {bg.name}
              </span>
            </div>
          </div>
        ))}
      </div>
    );
  } catch (error) {
    console.error('HeroBackgrounds error:', error);
    return null;
  }
}