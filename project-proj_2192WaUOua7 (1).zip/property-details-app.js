function PropertyDetailsApp() {
  const [property, setProperty] = React.useState(null);
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    loadProperty();
  }, []);

  const loadProperty = async () => {
    const params = new URLSearchParams(window.location.search);
    const propertyId = params.get('id');
    
    if (!propertyId) {
      window.location.href = 'index.html';
      return;
    }

    try {
      const prop = await trickleGetObject('property', propertyId);
      setProperty(prop);
    } catch (error) {
      console.error('Load property error:', error);
      alert('حدث خطأ في تحميل العقار');
    }
    setLoading(false);
  };

  if (loading || !property) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-[var(--primary-color)] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-xl font-semibold text-gray-700">جاري تحميل تفاصيل العقار...</p>
        </div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-xl">لم يتم العثور على العقار</div>
      </div>
    );
  }

  const data = property.objectData;
  const images = data.images || [];
  const currentImage = images[currentImageIndex] || 'https://images.unsplash.com/photo-1582407947304-fd86f028f716?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80';

  return (
    <div className="min-h-screen bg-[var(--light-bg)]">
      <header className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <button 
            onClick={() => window.location.href = 'index.html'}
            className="flex items-center gap-2 text-[var(--primary-color)] hover:text-[var(--secondary-color)]">
            <div className="icon-arrow-right text-xl"></div>
            <span className="font-semibold">العودة للرئيسية</span>
          </button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="relative h-96 md:h-[500px] bg-gray-200">
            <img src={currentImage} alt={data.title} className="w-full h-full object-cover" />
            
            {images.length > 1 && (
              <>
                <button 
                  onClick={() => setCurrentImageIndex((currentImageIndex - 1 + images.length) % images.length)}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-white bg-opacity-80 p-3 rounded-full hover:bg-opacity-100">
                  <div className="icon-chevron-left text-xl"></div>
                </button>
                <button 
                  onClick={() => setCurrentImageIndex((currentImageIndex + 1) % images.length)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-white bg-opacity-80 p-3 rounded-full hover:bg-opacity-100">
                  <div className="icon-chevron-right text-xl"></div>
                </button>
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                  {images.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentImageIndex(idx)}
                      className={`w-2 h-2 rounded-full ${idx === currentImageIndex ? 'bg-white' : 'bg-white bg-opacity-50'}`}
                    />
                  ))}
                </div>
              </>
            )}

            {data.status === 'sold' && (
              <div className="absolute top-4 right-4 bg-red-500 text-white px-4 py-2 rounded-full font-semibold">
                تم البيع
              </div>
            )}
            {data.status === 'available' && (
              <div className="absolute top-4 right-4 bg-green-500 text-white px-4 py-2 rounded-full font-semibold">
                متاح
              </div>
            )}
          </div>

          <div className="p-6 md:p-8">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{data.title}</h1>
            
            <div className="flex items-center gap-2 text-gray-600 mb-6">
              <div className="icon-map-pin text-xl text-[var(--primary-color)]"></div>
              <span className="text-lg">{data.region}</span>
            </div>

            <div className="text-4xl font-bold text-[var(--primary-color)] mb-8">
              {data.price} جنيه
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {data.area && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="icon-maximize text-2xl text-[var(--primary-color)] mb-2"></div>
                  <div className="text-sm text-gray-600">المساحة</div>
                  <div className="text-xl font-bold">{data.area} م²</div>
                </div>
              )}
              {data.bedrooms && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="icon-bed text-2xl text-[var(--primary-color)] mb-2"></div>
                  <div className="text-sm text-gray-600">غرف النوم</div>
                  <div className="text-xl font-bold">{data.bedrooms}</div>
                </div>
              )}
              {data.bathrooms && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="icon-bath text-2xl text-[var(--primary-color)] mb-2"></div>
                  <div className="text-sm text-gray-600">الحمامات</div>
                  <div className="text-xl font-bold">{data.bathrooms}</div>
                </div>
              )}
              {data.parking && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="icon-car text-2xl text-[var(--primary-color)] mb-2"></div>
                  <div className="text-sm text-gray-600">المواقف</div>
                  <div className="text-xl font-bold">{data.parking}</div>
                </div>
              )}
            </div>

            <div className="border-t pt-6 mb-6">
              <h2 className="text-2xl font-bold mb-4">المميزات</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <div className="icon-home text-xl text-green-600"></div>
                  <span>النوع: {data.type === 'residential' ? 'سكني' : 'تجاري'}</span>
                </div>
                {data.floors && (
                  <div className="flex items-center gap-3">
                    <div className="icon-layers text-xl text-green-600"></div>
                    <span>عدد الطوابق: {data.floors}</span>
                  </div>
                )}
                {data.furnished && (
                  <div className="flex items-center gap-3">
                    <div className="icon-sofa text-xl text-green-600"></div>
                    <span>التأثيث: {data.furnished}</span>
                  </div>
                )}
                {data.yearBuilt && (
                  <div className="flex items-center gap-3">
                    <div className="icon-calendar text-xl text-green-600"></div>
                    <span>سنة البناء: {data.yearBuilt}</span>
                  </div>
                )}
                {data.condition && (
                  <div className="flex items-center gap-3">
                    <div className="icon-award text-xl text-green-600"></div>
                    <span>الحالة: {data.condition}</span>
                  </div>
                )}
                {data.securitySystem && data.securitySystem !== 'غير متوفر' && (
                  <div className="flex items-center gap-3">
                    <div className="icon-shield-check text-xl text-green-600"></div>
                    <span>الأمان: {data.securitySystem}</span>
                  </div>
                )}
                {data.garden && data.garden !== 'غير متوفر' && (
                  <div className="flex items-center gap-3">
                    <div className="icon-trees text-xl text-green-600"></div>
                    <span>{data.garden}</span>
                  </div>
                )}
                {data.swimmingPool && data.swimmingPool !== 'غير متوفر' && (
                  <div className="flex items-center gap-3">
                    <div className="icon-waves text-xl text-green-600"></div>
                    <span>{data.swimmingPool}</span>
                  </div>
                )}
                {data.elevator && data.elevator === 'متوفر' && (
                  <div className="flex items-center gap-3">
                    <div className="icon-arrow-up text-xl text-green-600"></div>
                    <span>مصعد متوفر</span>
                  </div>
                )}
                {data.centralAC && data.centralAC === 'متوفر' && (
                  <div className="flex items-center gap-3">
                    <div className="icon-wind text-xl text-green-600"></div>
                    <span>تكييف مركزي</span>
                  </div>
                )}
                {data.view && (
                  <div className="flex items-center gap-3">
                    <div className="icon-eye text-xl text-green-600"></div>
                    <span>إطلالة: {data.view}</span>
                  </div>
                )}
                {data.balcony && data.balcony === 'متوفرة' && (
                  <div className="flex items-center gap-3">
                    <div className="icon-door-open text-xl text-green-600"></div>
                    <span>بلكونة متوفرة</span>
                  </div>
                )}
                {data.basement && data.basement === 'متوفر' && (
                  <div className="flex items-center gap-3">
                    <div className="icon-box text-xl text-green-600"></div>
                    <span>قبو/طابق سفلي</span>
                  </div>
                )}
              </div>
            </div>

            {(data.nearMosque || data.nearSchool || data.nearHospital || data.nearMarket || data.nearTransport) && (
              <div className="border-t pt-6 mb-6">
                <h2 className="text-2xl font-bold mb-4">القرب من الخدمات</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.nearMosque && (
                    <div className="flex items-center gap-3">
                      <div className="icon-church text-xl text-blue-600"></div>
                      <span>مسجد: {data.nearMosque}</span>
                    </div>
                  )}
                  {data.nearSchool && (
                    <div className="flex items-center gap-3">
                      <div className="icon-graduation-cap text-xl text-blue-600"></div>
                      <span>مدارس: {data.nearSchool}</span>
                    </div>
                  )}
                  {data.nearHospital && (
                    <div className="flex items-center gap-3">
                      <div className="icon-heart-pulse text-xl text-blue-600"></div>
                      <span>مستشفى: {data.nearHospital}</span>
                    </div>
                  )}
                  {data.nearMarket && (
                    <div className="flex items-center gap-3">
                      <div className="icon-shopping-cart text-xl text-blue-600"></div>
                      <span>أسواق: {data.nearMarket}</span>
                    </div>
                  )}
                  {data.nearTransport && (
                    <div className="flex items-center gap-3">
                      <div className="icon-bus text-xl text-blue-600"></div>
                      <span>مواصلات: {data.nearTransport}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {(data.internet || data.solarPower || data.waterTank || data.generator || data.smartHome) && (
              <div className="border-t pt-6 mb-6">
                <h2 className="text-2xl font-bold mb-4">المرافق والتقنيات</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {data.internet && data.internet !== 'غير متوفر' && (
                    <div className="flex items-center gap-3">
                      <div className="icon-wifi text-xl text-purple-600"></div>
                      <span>إنترنت: {data.internet}</span>
                    </div>
                  )}
                  {data.solarPower && data.solarPower === 'متوفرة' && (
                    <div className="flex items-center gap-3">
                      <div className="icon-sun text-xl text-purple-600"></div>
                      <span>طاقة شمسية متوفرة</span>
                    </div>
                  )}
                  {data.waterTank && data.waterTank === 'متوفر' && (
                    <div className="flex items-center gap-3">
                      <div className="icon-droplet text-xl text-purple-600"></div>
                      <span>خزان مياه</span>
                    </div>
                  )}
                  {data.generator && data.generator === 'متوفر' && (
                    <div className="flex items-center gap-3">
                      <div className="icon-zap text-xl text-purple-600"></div>
                      <span>مولد كهربائي</span>
                    </div>
                  )}
                  {data.smartHome && data.smartHome !== 'غير متوفر' && (
                    <div className="flex items-center gap-3">
                      <div className="icon-smartphone text-xl text-purple-600"></div>
                      <span>منزل ذكي: {data.smartHome}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            <div className="border-t pt-6">
              <h2 className="text-2xl font-bold mb-4">الوصف</h2>
              <p className="text-lg text-gray-700 leading-relaxed">{data.description}</p>
            </div>

            {data.videos && data.videos.length > 0 && (
              <div className="border-t pt-6 mt-6">
                <h2 className="text-2xl font-bold mb-4">فيديو العقار</h2>
                <video controls className="w-full rounded-lg">
                  <source src={data.videos[0]} type="video/mp4" />
                </video>
              </div>
            )}

            <div className="border-t pt-6 mt-6">
              <h3 className="text-xl font-bold mb-4 text-center">تواصل معنا</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <a 
                  href={`mailto:info@general.com?subject=استفسار عن ${data.title}&body=مرحباً، أنا مهتم بالعقار: ${data.title}%0D%0A%0D%0Aالسعر: ${data.price} جنيه%0D%0Aالمنطقة: ${data.region}`}
                  className="flex flex-col items-center gap-3 bg-blue-50 hover:bg-blue-100 p-6 rounded-xl transition-all border-2 border-blue-200 hover:border-blue-400">
                  <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center">
                    <div className="icon-mail text-3xl text-white"></div>
                  </div>
                  <span className="font-bold text-blue-700">البريد الإلكتروني</span>
                  <span className="text-sm text-gray-600 text-center">أرسل رسالة عبر الإيميل</span>
                </a>

                <a 
                  href={`https://wa.me/201034551612?text=مرحباً، أنا مهتم بالعقار: ${data.title}%0D%0A%0D%0Aالسعر: ${data.price} جنيه%0D%0Aالمنطقة: ${data.region}`}
                  target="_blank"
                  className="flex flex-col items-center gap-3 bg-green-50 hover:bg-green-100 p-6 rounded-xl transition-all border-2 border-green-200 hover:border-green-400">
                  <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center">
                    <div className="icon-message-circle text-3xl text-white"></div>
                  </div>
                  <span className="font-bold text-green-700">واتساب</span>
                  <span className="text-sm text-gray-600 text-center">تواصل عبر الواتساب</span>
                </a>

                <a 
                  href="tel:+201034551612"
                  className="flex flex-col items-center gap-3 bg-orange-50 hover:bg-orange-100 p-6 rounded-xl transition-all border-2 border-orange-200 hover:border-orange-400">
                  <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center">
                    <div className="icon-phone text-3xl text-white"></div>
                  </div>
                  <span className="font-bold text-orange-700">اتصال هاتفي</span>
                  <span className="text-sm text-gray-600 text-center">مكالمة صوتية مباشرة</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<PropertyDetailsApp />);