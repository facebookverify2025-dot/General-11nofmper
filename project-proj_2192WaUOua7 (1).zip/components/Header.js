function Header({ currentPage, onNavigate, isAdmin }) {
  try {
    const [isMenuOpen, setIsMenuOpen] = React.useState(false);

    const menuItems = [
      { id: 'home', label: 'الرئيسية', icon: 'home' },
      { id: 'about', label: 'من نحن', icon: 'users' },
      { id: 'projects', label: 'المشاريع', icon: 'building-2' },
      { id: 'maps', label: 'الخرائط', icon: 'map' },
      { id: 'contact', label: 'تواصل معنا', icon: 'phone' }
    ];

    return (
      <header className="bg-white shadow-md sticky top-0 z-50" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
          <div className="flex items-center gap-2 md:gap-3">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-[var(--primary-color)] rounded-lg flex items-center justify-center">
              <div className="icon-building-2 text-xl md:text-2xl text-white"></div>
            </div>
            <div>
              <h1 className="text-base sm:text-lg md:text-2xl font-bold text-[var(--dark-color)]">الجنرال</h1>
              <p className="text-xs hidden sm:block text-gray-600">مسوق عقارات حقيقي في مدينة السادات</p>
            </div>
          </div>

            <nav className="hidden lg:flex items-center gap-4 xl:gap-6">
              {menuItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                    currentPage === item.id ? 'bg-[var(--primary-color)] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <div className={`icon-${item.icon} text-lg`}></div>
                  <span className="font-semibold">{item.label}</span>
                </button>
              ))}
            </nav>

            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="lg:hidden p-2">
              <div className={`icon-${isMenuOpen ? 'x' : 'menu'} text-2xl text-[var(--dark-color)]`}></div>
            </button>
          </div>

          {isMenuOpen && (
            <nav className="lg:hidden py-4 border-t">
              {menuItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => { onNavigate(item.id); setIsMenuOpen(false); }}
                  className={`w-full text-right px-4 py-3 rounded-lg flex items-center gap-3 ${
                    currentPage === item.id ? 'bg-[var(--primary-color)] text-white' : 'hover:bg-gray-100'
                  }`}
                >
                  <div className={`icon-${item.icon} text-lg`}></div>
                  <span className="font-semibold">{item.label}</span>
                </button>
              ))}
            </nav>
          )}
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}