function SoundManager({ onUpdate }) {
  try {
    const [settings, setSettings] = React.useState(null);
    const [sounds, setSounds] = React.useState({
      clickSound: ''
    });
    const [uploading, setUploading] = React.useState(false);
    const addPropertyInputRef = React.useRef(null);

    React.useEffect(() => {
      loadSettings();
    }, []);

    const loadSettings = async () => {
      const s = await Database.getSettings();
      setSettings(s);
      setSounds({
        clickSound: s.objectData?.clickSound || ''
      });
    };

    const handleSoundUpload = async (e, soundType) => {
      const file = e.target.files[0];
      if (!file) return;
      
      if (!file.type.startsWith('audio/')) {
        alert('الرجاء اختيار ملف صوتي فقط');
        e.target.value = '';
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        alert('حجم الملف كبير جداً. الحد الأقصى 5 ميجابايت');
        e.target.value = '';
        return;
      }
      
      setUploading(true);
      
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64Audio = event.target.result;
        setSounds({...sounds, [soundType]: base64Audio});
        setUploading(false);
        e.target.value = '';
      };
      reader.onerror = () => {
        alert('حدث خطأ في قراءة الملف');
        setUploading(false);
        e.target.value = '';
      };
      reader.readAsDataURL(file);
    };

    const handleSave = async () => {
      if (!settings || !settings.objectId) {
        alert('خطأ في تحميل الإعدادات');
        return;
      }
      
      try {
        const currentData = settings.objectData || {};
        const updatedData = {
          ...currentData,
          clickSound: sounds.clickSound
        };
        
        await Database.updateSettings(settings.objectId, updatedData);
        alert('تم حفظ الأصوات بنجاح');
        await loadSettings();
        onUpdate();
      } catch (error) {
        alert('حدث خطأ في الحفظ');
      }
    };

    const playSound = (soundData) => {
      if (!soundData) {
        alert('لم يتم رفع صوت لهذا الزر بعد');
        return;
      }
      const audio = new Audio(soundData);
      audio.play().catch(() => alert('حدث خطأ في تشغيل الصوت'));
    };

    if (!settings) return <div>جاري التحميل...</div>;

    return (
      <div className="space-y-6" data-name="sound-manager" data-file="components/SoundManager.js">
        <h3 className="text-xl font-bold mb-4">إدارة الأصوات التفاعلية</h3>
        <p className="text-gray-600 mb-4">ارفع ملف صوتي واحد لجميع الضغطات في التطبيق</p>
        
        <div className="border rounded-lg p-6">
          <label className="block font-semibold mb-4 text-lg">صوت الضغطات في التطبيق</label>
          <p className="text-sm text-gray-600 mb-4">سيتم تشغيل هذا الصوت عند: إضافة عقار، إضافة منطقة، تغيير الثيم، وجميع الضغطات الأخرى</p>
          <input 
            type="file"
            ref={addPropertyInputRef}
            onChange={(e) => handleSoundUpload(e, 'clickSound')}
            accept="audio/*"
            className="hidden"
          />
          <div className="flex gap-3">
            <button 
              onClick={() => addPropertyInputRef.current?.click()}
              disabled={uploading}
              className="flex-1 px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all flex items-center justify-center gap-2">
              <div className="icon-upload text-xl"></div>
              {uploading ? 'جاري الرفع...' : 'اختر ملف صوتي'}
            </button>
            {sounds.clickSound && (
              <button 
                onClick={() => playSound(sounds.clickSound)}
                className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all flex items-center gap-2">
                <div className="icon-volume-2 text-xl"></div>
                تجربة الصوت
              </button>
            )}
          </div>
          {sounds.clickSound && (
            <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center gap-2">
                <div className="icon-check-circle text-lg text-green-600"></div>
                <p className="text-sm text-green-700 font-semibold">تم رفع الصوت بنجاح</p>
              </div>
            </div>
          )}
        </div>
        
        <button onClick={handleSave} className="btn-primary w-full">
          حفظ الأصوات
        </button>
      </div>
    );
  } catch (error) {
    console.error('SoundManager error:', error);
    return null;
  }
}