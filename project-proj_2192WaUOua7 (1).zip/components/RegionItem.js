function RegionItem({ region, onUpdate }) {
  try {
    const [showForm, setShowForm] = React.useState(false);
    const [showMapUpload, setShowMapUpload] = React.useState(false);
    const [properties, setProperties] = React.useState([]);
    const [mapUrl, setMapUrl] = React.useState(region.objectData.mapImage || '');
    const [uploading, setUploading] = React.useState(false);
    const mapFileInputRef = React.useRef(null);

    React.useEffect(() => {
      loadProperties();
    }, []);

    const loadProperties = async () => {
      const allProps = await Database.getProperties();
      setProperties(allProps.filter(p => p.objectData.region === region.objectData.name));
    };

    const handleDeleteProperty = async (propertyId) => {
      if (!confirm('هل أنت متأكد من حذف هذا العقار؟')) return;
      try {
        await Database.deleteProperty(propertyId);
        loadProperties();
        onUpdate();
        alert('تم حذف العقار بنجاح');
      } catch (error) {
        alert('حدث خطأ في حذف العقار');
      }
    };

    const handleMapFileUpload = async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      
      const fileSize = file.size;
      
      if (fileSize > 10 * 1024 * 1024) {
        alert('حجم الملف كبير جداً. الحد الأقصى 10 ميجابايت');
        e.target.value = '';
        return;
      }
      
      setUploading(true);
      
      try {
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await fetch('https://tmpfiles.org/api/v1/upload', {
          method: 'POST',
          body: formData
        });
        
        if (!response.ok) {
          throw new Error('فشل رفع الملف');
        }
        
        const result = await response.json();
        
        if (result.status !== 'success' || !result.data || !result.data.url) {
          throw new Error('فشل في الحصول على رابط الملف');
        }
        
        let fileUrl = result.data.url;
        fileUrl = fileUrl.replace('tmpfiles.org/', 'tmpfiles.org/dl/');
        
        const updatedData = {
          name: region.objectData.name,
          mapImage: fileUrl
        };
        
        await Database.updateRegion(region.objectId, updatedData);
        
        setMapUrl(fileUrl);
        setShowMapUpload(false);
        alert('تم رفع الخريطة وحفظها بنجاح ✓');
        onUpdate();
        
      } catch (error) {
        console.error('Upload error:', error);
        alert('حدث خطأ في رفع الملف. حاول مرة أخرى');
      } finally {
        setUploading(false);
        e.target.value = '';
      }
    };

    const handleDeleteRegion = async () => {
      if (!confirm('هل أنت متأكد من حذف هذه المنطقة؟ سيتم حذف جميع العقارات المرتبطة بها')) return;
      try {
        const regionProps = await Database.getProperties();
        const propsToDelete = regionProps.filter(p => p.objectData.region === region.objectData.name);
        
        for (const prop of propsToDelete) {
          await Database.deleteProperty(prop.objectId);
        }
        
        await Database.deleteRegion(region.objectId);
        alert('تم حذف المنطقة بنجاح');
        onUpdate();
      } catch (error) {
        alert('حدث خطأ في حذف المنطقة');
      }
    };

    return (
      <div className="border rounded-lg p-4 bg-gray-50">
        <div className="flex justify-between items-center mb-4">
          <h4 className="text-lg font-bold">{region.objectData.name}</h4>
          <div className="flex gap-2">
            <button onClick={() => setShowMapUpload(!showMapUpload)} className="px-3 py-1 bg-blue-500 text-white rounded text-sm hover:bg-blue-600">
              {showMapUpload ? 'إلغاء' : 'إضافة خريطة'}
            </button>
            <button onClick={() => setShowForm(!showForm)} className="px-3 py-1 bg-[var(--primary-color)] text-white rounded text-sm hover:bg-[var(--secondary-color)]">
              {showForm ? 'إلغاء' : 'إضافة عقار'}
            </button>
            <button onClick={handleDeleteRegion} className="px-3 py-1 bg-red-500 text-white rounded text-sm hover:bg-red-600 flex items-center gap-1">
              <div className="icon-trash-2 text-sm"></div>
              حذف المنطقة
            </button>
          </div>
        </div>

        {showMapUpload && (
          <div className="bg-white p-4 rounded-lg mb-4 border">
            <div className="mb-3">
              <label className="block font-semibold mb-2 text-sm">رفع ملف من الجهاز</label>
              <input 
                type="file"
                ref={mapFileInputRef}
                onChange={handleMapFileUpload}
                accept="image/*,application/pdf,.dwg"
                className="hidden"
              />
              <button 
                type="button"
                onClick={() => mapFileInputRef.current?.click()}
                disabled={uploading}
                className="w-full px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all flex items-center justify-center gap-2 text-sm"
              >
                <div className="icon-upload text-lg"></div>
                {uploading ? 'جاري الرفع والحفظ...' : 'اختر صورة أو PDF أو DWG'}
              </button>
              <p className="text-xs text-gray-500 mt-1">سيتم حفظ الملف تلقائياً بعد اختياره</p>
            </div>

            <div className="relative mb-3">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-xs">
                <span className="bg-white px-2 text-gray-500">أو</span>
              </div>
            </div>

            <div className="mb-3">
              <label className="block font-semibold mb-2 text-sm">رابط الخريطة</label>
              <input 
                type="url"
                value={mapUrl}
                onChange={e => setMapUrl(e.target.value)}
                onBlur={async () => {
                  if (mapUrl && mapUrl.trim() !== '' && mapUrl.startsWith('http')) {
                    try {
                      const updatedData = {
                        ...region.objectData,
                        mapImage: mapUrl
                      };
                      await Database.updateRegion(region.objectId, updatedData);
                      alert('تم حفظ الخريطة بنجاح');
                      setShowMapUpload(false);
                      onUpdate();
                    } catch (error) {
                      alert('حدث خطأ في حفظ الرابط');
                    }
                  }
                }}
                placeholder="https://example.com/map.jpg أو رابط Google Drive"
                className="w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:border-blue-500"
              />
              <p className="text-xs text-gray-500 mt-2">
                ضع رابط الخريطة (صورة، PDF، Google Drive، أي رابط)
                <br />
                اضغط خارج الحقل للحفظ التلقائي
              </p>
            </div>

            {mapUrl && (
              <div className="mb-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center gap-2">
                  <div className="icon-check-circle text-lg text-green-600"></div>
                  <p className="text-sm text-green-700 font-semibold">تم إضافة الخريطة بنجاح</p>
                </div>
                <p className="text-xs text-green-600 mt-1">سيتم فتحها في تاب جديد عند الضغط عليها</p>
              </div>
            )}
          </div>
        )}

        {showForm && <PropertyForm regionName={region.objectData.name} onSuccess={() => { setShowForm(false); loadProperties(); onUpdate(); }} />}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {properties.map(prop => (
            <div key={prop.objectId} className="border rounded p-3 bg-white">
              <div className="flex justify-between items-start mb-2">
                <div className="flex-1">
                  <p className="font-semibold">{prop.objectData.title}</p>
                  <p className="text-sm text-gray-600">{prop.objectData.price} جنيه</p>
                  <p className="text-xs text-gray-500">{prop.objectData.type === 'residential' ? 'سكني' : 'تجاري'}</p>
                </div>
                <button 
                  onClick={() => handleDeleteProperty(prop.objectId)}
                  className="px-2 py-1 bg-red-500 text-white rounded text-xs hover:bg-red-600"
                >
                  حذف
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  } catch (error) {
    console.error('RegionItem error:', error);
    return null;
  }
}
