function ProjectCard({ property, onNavigate, showDetails }) {
  try {
    const data = property.objectData;
    const imageUrl = data.images?.[0] || 'https://images.unsplash.com/photo-1582407947304-fd86f028f716?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80';

    const handleDetailsClick = () => {
      if (showDetails) {
        window.location.href = `property-details.html?id=${property.objectId}`;
      }
    };

    return (
      <div className="card" data-name="project-card" data-file="components/ProjectCard.js">
        <div className="relative h-44 sm:h-48 overflow-hidden">
          <img src={imageUrl} alt={data.title} className="w-full h-full object-cover" />
          {data.status === 'sold' && (
            <div className="absolute top-4 right-4 bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
              تم البيع
            </div>
          )}
          {data.status === 'available' && (
            <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
              متاح
            </div>
          )}
        </div>
        
        <div className="p-3 sm:p-4 md:p-6">
          <h3 className="text-base sm:text-lg md:text-xl font-bold mb-2">{data.title}</h3>
          <div className="flex items-center gap-2 text-gray-600 mb-2">
            <div className="icon-map-pin text-sm"></div>
            <span className="text-sm">{data.region}</span>
          </div>
          
          <div className="grid grid-cols-2 gap-2 mb-3 text-xs">
            {data.bedrooms && (
              <div className="flex items-center gap-1">
                <div className="icon-bed text-[var(--primary-color)]"></div>
                <span>{data.bedrooms} غرف</span>
              </div>
            )}
            {data.bathrooms && (
              <div className="flex items-center gap-1">
                <div className="icon-bath text-[var(--primary-color)]"></div>
                <span>{data.bathrooms} حمام</span>
              </div>
            )}
            {data.area && (
              <div className="flex items-center gap-1">
                <div className="icon-maximize text-[var(--primary-color)]"></div>
                <span>{data.area} م²</span>
              </div>
            )}
            {data.parking && (
              <div className="flex items-center gap-1">
                <div className="icon-car text-[var(--primary-color)]"></div>
                <span>{data.parking}</span>
              </div>
            )}
          </div>
          
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">{data.description}</p>
          
          {(data.nearMosque || data.nearSchool || data.internet) && (
            <div className="flex flex-wrap gap-2 mb-3">
              {data.nearMosque && (
                <span className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-full flex items-center gap-1">
                  <div className="icon-church" style={{fontSize: '10px'}}></div>
                  مسجد قريب
                </span>
              )}
              {data.nearSchool && (
                <span className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded-full flex items-center gap-1">
                  <div className="icon-graduation-cap" style={{fontSize: '10px'}}></div>
                  مدارس قريبة
                </span>
              )}
              {data.internet && data.internet !== 'غير متوفر' && (
                <span className="text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded-full flex items-center gap-1">
                  <div className="icon-wifi" style={{fontSize: '10px'}}></div>
                  إنترنت
                </span>
              )}
            </div>
          )}
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 sm:gap-0">
            <span className="text-lg sm:text-xl md:text-2xl font-bold text-[var(--primary-color)]">{data.price} جنيه</span>
            <button 
              onClick={handleDetailsClick}
              className="px-4 py-2 bg-[var(--primary-color)] text-white rounded-lg hover:bg-[var(--secondary-color)] transition-all text-sm sm:text-base w-full sm:w-auto">
              التفاصيل
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ProjectCard component error:', error);
    return null;
  }
}