function MapsPage({ regions }) {
  try {
    const mapRef = React.useRef(null);
    const googleMapRef = React.useRef(null);

    React.useEffect(() => {
      if (mapRef.current && !googleMapRef.current && window.google) {
        const sadatCity = { lat: 30.3753, lng: 30.5669 };
        
        googleMapRef.current = new google.maps.Map(mapRef.current, {
          center: sadatCity,
          zoom: 13,
          mapTypeId: 'roadmap',
          language: 'ar'
        });

        new google.maps.Marker({
          position: sadatCity,
          map: googleMapRef.current,
          title: 'مدينة السادات'
        });
      }
    }, []);

    const handleOpenMap = (region) => {
      if (!region.objectData.mapImage) {
        alert('لم يتم إضافة خريطة لهذه المنطقة بعد');
        return;
      }

      const mapData = region.objectData.mapImage;
      
      if (mapData.startsWith('http')) {
        window.open(mapData, '_blank');
      } else {
        const urlParts = mapData.split('|');
        const dataUrl = urlParts[0];
        const fileName = urlParts[1] || 'map';
        const fileType = urlParts[2] || '';

        const newWindow = window.open('', '_blank');
        
        if (fileType === 'application/pdf' || fileName.toLowerCase().endsWith('.pdf')) {
          newWindow.document.write(`
            <!DOCTYPE html>
            <html lang="ar" dir="rtl">
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>خريطة ${region.objectData.name}</title>
              <style>
                body { margin: 0; padding: 0; overflow: hidden; }
                iframe { width: 100vw; height: 100vh; border: none; }
              </style>
            </head>
            <body>
              <iframe src="${dataUrl}" title="PDF Map"></iframe>
            </body>
            </html>
          `);
        } else if (fileName.toLowerCase().endsWith('.dwg')) {
          newWindow.document.write(`
            <!DOCTYPE html>
            <html lang="ar" dir="rtl">
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>خريطة ${region.objectData.name}</title>
              <style>
                body { 
                  margin: 0; 
                  padding: 40px; 
                  font-family: Arial, sans-serif;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  min-height: 100vh;
                  background: #f5f5f5;
                }
                .container {
                  text-align: center;
                  background: white;
                  padding: 60px;
                  border-radius: 10px;
                  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
                }
                h1 { color: #333; margin-bottom: 20px; }
                p { color: #666; margin-bottom: 30px; }
                a {
                  display: inline-block;
                  background: #2196F3;
                  color: white;
                  padding: 15px 30px;
                  text-decoration: none;
                  border-radius: 5px;
                  font-weight: bold;
                  transition: background 0.3s;
                }
                a:hover { background: #1976D2; }
              </style>
            </head>
            <body>
              <div class="container">
                <h1>ملف DWG - ${region.objectData.name}</h1>
                <p>قم بتحميل الملف لفتحه في برنامج AutoCAD أو أي برنامج متوافق</p>
                <a href="${dataUrl}" download="${fileName}">تحميل الملف</a>
              </div>
            </body>
            </html>
          `);
        } else {
          newWindow.document.write(`
            <!DOCTYPE html>
            <html lang="ar" dir="rtl">
            <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>خريطة ${region.objectData.name}</title>
              <style>
                body { 
                  margin: 0; 
                  padding: 0; 
                  overflow: auto; 
                  background: #000;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  min-height: 100vh;
                }
                img { 
                  max-width: 100%; 
                  height: auto; 
                  display: block;
                }
              </style>
            </head>
            <body>
              <img src="${dataUrl}" alt="خريطة ${region.objectData.name}" />
            </body>
            </html>
          `);
        }
        
        newWindow.document.close();
      }
    };

    return (
      <div className="py-16 bg-white" data-name="maps-page" data-file="pages/maps.js">
        <div className="container mx-auto px-4">
          <h1 className="section-title">الخرائط</h1>
          
          <div className="mb-12">
            <div className="card overflow-hidden">
              <div className="bg-gradient-to-r from-[var(--primary-color)] to-[var(--secondary-color)] p-6 text-white">
                <h2 className="text-3xl font-bold mb-2">خريطة مدينة السادات</h2>
                <p className="text-lg">خريطة تفاعلية من Google Maps</p>
              </div>
              <div ref={mapRef} className="w-full h-[500px]"></div>
            </div>
          </div>

          <h2 className="text-2xl font-bold mb-6">خرائط المناطق</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {regions.map(region => (
              <div 
                key={region.objectId}
                onClick={() => handleOpenMap(region)}
                className="card cursor-pointer hover:shadow-xl transition-shadow"
              >
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <div className="icon-map text-xl text-blue-600"></div>
                    </div>
                    <h3 className="text-xl font-bold">{region.objectData.name}</h3>
                  </div>
                  {region.objectData.mapImage ? (
                    <div className="flex items-center gap-2">
                      <div className="icon-external-link text-sm text-green-600"></div>
                      <p className="text-green-600 text-sm font-semibold">اضغط لفتح الخريطة</p>
                    </div>
                  ) : (
                    <p className="text-gray-500 text-sm">لم تُضف خريطة بعد</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('MapsPage error:', error);
    return null;
  }
}
