const Database = {
  async getRegions() {
    const result = await trickleListObjects('region', 200, true);
    return result.items || [];
  },

  async createRegion(name) {
    try {
      return await trickleCreateObject('region', { name, createdAt: new Date().toISOString() });
    } catch (error) {
      console.error('Create region error:', error);
      throw error;
    }
  },

  async updateRegion(objectId, regionData) {
    try {
      if (!objectId) {
        throw new Error('Region ID is required');
      }
      if (!regionData || typeof regionData !== 'object') {
        throw new Error('Invalid region data');
      }
      const result = await trickleUpdateObject('region', objectId, regionData);
      return result;
    } catch (error) {
      console.error('Update region error:', error);
      throw new Error(`فشل تحديث المنطقة: ${error.message}`);
    }
  },

  async getProperties() {
    const result = await trickleListObjects('property', 200, true);
    return result.items || [];
  },

  async createProperty(propertyData) {
    try {
      return await trickleCreateObject('property', { ...propertyData, createdAt: new Date().toISOString() });
    } catch (error) {
      console.error('Create property error:', error);
      throw error;
    }
  },

  async updateProperty(objectId, propertyData) {
    try {
      return await trickleUpdateObject('property', objectId, propertyData);
    } catch (error) {
      console.error('Update property error:', error);
      throw error;
    }
  },

  async getSettings() {
    const result = await trickleListObjects('settings', 1, true);
    if (result.items && result.items.length > 0) {
      return result.items[0];
    }
    const defaultSettings = {
      companyEmail: 'info@general.com',
      whatsappNumber: '+201034551612',
      facebookUrl: '',
      instagramUrl: '',
      heroImageUrl: 'https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80'
    };
    return await trickleCreateObject('settings', defaultSettings);
  },

  async updateSettings(objectId, settingsData) {
    try {
      return await trickleUpdateObject('settings', objectId, settingsData);
    } catch (error) {
      console.error('Update settings error:', error);
      throw error;
    }
  },

  async createMessage(messageData) {
    try {
      return await trickleCreateObject('message', { ...messageData, createdAt: new Date().toISOString(), read: false });
    } catch (error) {
      console.error('Create message error:', error);
      throw error;
    }
  },

  async getMessages() {
    try {
      const result = await trickleListObjects('message', 100, true);
      return result.items || [];
    } catch (error) {
      console.error('Get messages error:', error);
      return [];
    }
  },

  async deleteProperty(objectId) {
    try {
      return await trickleDeleteObject('property', objectId);
    } catch (error) {
      console.error('Delete property error:', error);
      throw error;
    }
  },

  async deleteRegion(objectId) {
    try {
      return await trickleDeleteObject('region', objectId);
    } catch (error) {
      console.error('Delete region error:', error);
      throw error;
    }
  }
};
